package transporte;

public interface EstrategiaTransporte {
    void viajar(String destino);
}
